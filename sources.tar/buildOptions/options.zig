pub const version: []const u8 = "0.0.3";
pub const name: []const u8 = "zserial";
pub const docs: bool = true;
